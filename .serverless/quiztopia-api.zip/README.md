# Quiztopia-API
Ett backend-API för "Quiztopia" – ett system där användare kan skapa, spela och hantera quiz kopplade till geografiska platser.
